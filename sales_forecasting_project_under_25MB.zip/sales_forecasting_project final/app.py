from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect
from flask_bcrypt import Bcrypt

import os
import re
import io
import csv
import hashlib
from datetime import date
import pandas as pd

from werkzeug.utils import secure_filename

import plotly.express as px
import plotly.io as pio

from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error


# =========================================================
# CREATE FLASK APPLICATION
# =========================================================

app = Flask(__name__)


# =========================================================
# APPLICATION CONFIGURATION
# =========================================================

app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "change-this-development-secret-key")

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


# =========================================================
# DATABASE
# =========================================================

db = SQLAlchemy(app)

bcrypt = Bcrypt(app)


# =========================================================
# CSV UPLOAD CONFIGURATION
# =========================================================

UPLOAD_FOLDER = "uploads"

ALLOWED_EXTENSIONS = {"csv"}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# =========================================================
# CHECK CSV FILE
# =========================================================

def allowed_file(filename):

    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


# =========================================================
# USER MODEL
# =========================================================

class User(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    name = db.Column(
        db.String(100),
        nullable=False
    )

    email = db.Column(
        db.String(120),
        unique=True,
        nullable=False
    )

    username = db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )

    password = db.Column(
        db.String(200),
        nullable=False
    )


# =========================================================
# SALES DATA MODEL
# =========================================================

class SalesData(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    # IMPORTANT:
    # Every sales record belongs to one user

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("user.id"),
        nullable=False
    )

    date = db.Column(
        db.Date,
        nullable=False
    )

    product_name = db.Column(
        db.String(150),
        nullable=False
    )

    product_category = db.Column(
        db.String(100),
        nullable=False
    )

    quantity = db.Column(
        db.Integer,
        nullable=False
    )

    price = db.Column(
        db.Float,
        nullable=False
    )

    # Unit purchase cost. Nullable for legacy records or imports without cost data.
    cost_price = db.Column(db.Float, nullable=True)

    customer_location = db.Column(
        db.String(150),
        nullable=False
    )


class UploadHistory(db.Model):
    """Remember imported file hashes so the exact same CSV is not imported twice."""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    file_hash = db.Column(db.String(64), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp(), nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "file_hash", name="uq_user_upload_hash"),)


class InventoryStock(db.Model):
    """Optional current stock snapshot supplied by CSV, isolated per user/product."""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    product_name = db.Column(db.String(150), nullable=False)
    stock_on_hand = db.Column(db.Integer, nullable=False, default=0)
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp(), nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "product_name", name="uq_user_inventory_product"),)


# =========================================================
# PASSWORD VALIDATION
# =========================================================

def validate_password(password):

    if len(password) < 8:
        return False

    if not re.search(r"[A-Z]", password):
        return False

    if not re.search(r"[a-z]", password):
        return False

    if not re.search(r"[0-9]", password):
        return False

    if not re.search(r"[!@#$%^&*]", password):
        return False

    return True


# =========================================================
# LOGIN CHECK
# =========================================================

def login_required():

    return "user_id" in session


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():

    return render_template("home.html")


# =========================================================
# REGISTER
# =========================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name", "").strip()

        email = request.form.get("email", "").strip()

        username = request.form.get("username", "").strip()

        password = request.form.get("password", "")

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )


        # -----------------------------
        # EMPTY FIELD CHECK
        # -----------------------------

        if not name or not email or not username or not password:

            flash("All fields are required!")

            return redirect(
                url_for("register")
            )


        # -----------------------------
        # PASSWORD MATCH
        # -----------------------------

        if password != confirm_password:

            flash("Passwords do not match!")

            return redirect(
                url_for("register")
            )


        # -----------------------------
        # PASSWORD VALIDATION
        # -----------------------------

        if not validate_password(password):

            flash(
                "Password must contain at least 8 characters, "
                "one uppercase letter, one lowercase letter, "
                "one number and one special character!"
            )

            return redirect(
                url_for("register")
            )


        # -----------------------------
        # CHECK EXISTING USER
        # -----------------------------

        existing_user = User.query.filter(
            (User.email == email) |
            (User.username == username)
        ).first()


        if existing_user:

            flash(
                "Username or Email already exists!"
            )

            return redirect(
                url_for("register")
            )


        # -----------------------------
        # HASH PASSWORD
        # -----------------------------

        hashed_password = bcrypt.generate_password_hash(
            password
        ).decode("utf-8")


        # -----------------------------
        # CREATE USER
        # -----------------------------

        new_user = User(

            name=name,

            email=email,

            username=username,

            password=hashed_password

        )


        db.session.add(new_user)

        db.session.commit()


        flash(
            "Registration Successful! Please Login."
        )


        return redirect(
            url_for("login")
        )


    return render_template(
        "register.html"
    )


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username_or_email = request.form.get(
            "username",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )


        user = User.query.filter(

            (User.username == username_or_email) |
            (User.email == username_or_email)

        ).first()


        if user and bcrypt.check_password_hash(
            user.password,
            password
        ):

            session.clear()

            session["user_id"] = user.id

            session["username"] = user.username


            flash(
                "Login Successful!"
            )


            return redirect(
                url_for("dashboard")
            )


        flash(
            "Invalid Username or Password!"
        )


    return render_template(
        "login.html"
    )


def calculate_profit_loss(records):
    """Calculate profit/loss only where unit purchase cost is known."""
    total_revenue = sum(float(r.quantity) * float(r.price) for r in records)
    known = [r for r in records if getattr(r, "cost_price", None) is not None]
    known_revenue = sum(float(r.quantity) * float(r.price) for r in known)
    total_cost = sum(float(r.quantity) * float(r.cost_price) for r in known)
    product_totals, weekly, monthly, yearly = {}, {}, {}, {}

    for r in records:
        revenue = float(r.quantity) * float(r.price)
        unit_cost = getattr(r, "cost_price", None)
        cost = float(r.quantity) * float(unit_cost) if unit_cost is not None else None
        profit = revenue - cost if cost is not None else None
        product = r.product_name
        row = product_totals.setdefault(product, {"product": product, "quantity": 0, "revenue": 0.0,
            "cost": 0.0, "profit": 0.0, "unknown_cost_records": 0})
        row["quantity"] += int(r.quantity)
        row["revenue"] += revenue
        if profit is None:
            row["unknown_cost_records"] += 1
        else:
            row["cost"] += cost
            row["profit"] += profit

        if r.date:
            iso = r.date.isocalendar()
            keys = ((weekly, f"{iso.year}-W{iso.week:02d}"),
                    (monthly, r.date.strftime("%Y-%m")), (yearly, str(r.date.year)))
            for bucket, key in keys:
                item = bucket.setdefault(key, {"period": key, "revenue": 0.0, "cost": 0.0,
                    "profit": 0.0, "unknown_cost_records": 0})
                item["revenue"] += revenue
                if profit is None:
                    item["unknown_cost_records"] += 1
                else:
                    item["cost"] += cost
                    item["profit"] += profit

    def finish(bucket, sort_key):
        output = []
        for item in sorted(bucket.values(), key=sort_key, reverse=True):
            item = dict(item)
            for key in ("revenue", "cost", "profit"):
                item[key] = round(item[key], 2)
            item["status"] = ("Cost missing" if item["unknown_cost_records"] else
                ("Profit" if item["profit"] > 0 else ("Loss" if item["profit"] < 0 else "Break-even")))
            output.append(item)
        return output

    return {
        "total_revenue": round(total_revenue, 2),
        "known_revenue": round(known_revenue, 2),
        "total_cost": round(total_cost, 2),
        "net_profit": round(known_revenue - total_cost, 2),
        "unknown_cost_records": len(records) - len(known),
        "product_profit_rows": finish(product_totals, lambda x: x["product"].casefold()),
        "weekly_profit_rows": finish(weekly, lambda x: x["period"]),
        "monthly_profit_rows": finish(monthly, lambda x: x["period"]),
        "yearly_profit_rows": finish(yearly, lambda x: x["period"]),
    }


def build_profit_loss_charts(summary):
    """Create product and time-period profit/loss charts from records with complete costs."""
    def chart(rows, x_key, title):
        complete = [r for r in rows if r.get("unknown_cost_records", 0) == 0]
        if not complete:
            return "<p>Profit/loss chart will appear when purchase cost is available for the relevant records.</p>"
        frame = pd.DataFrame(complete)
        fig = px.bar(frame, x=x_key, y="profit", title=title,
                     labels={"profit": "Profit / Loss (₹)", x_key: "Product" if x_key == "product" else "Period"},
                     color="profit", color_continuous_scale=["#c62828", "#16803c"])
        fig.update_layout(template="plotly_white", height=380, coloraxis_showscale=False)
        return pio.to_html(fig, full_html=False, config={"responsive": True, "displaylogo": False})
    return {
        "product": chart(summary["product_profit_rows"], "product", "Product-wise Profit / Loss"),
        "weekly": chart(summary["weekly_profit_rows"], "period", "Weekly Profit / Loss"),
        "monthly": chart(summary["monthly_profit_rows"], "period", "Monthly Profit / Loss"),
        "yearly": chart(summary["yearly_profit_rows"], "period", "Yearly Profit / Loss"),
    }


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))

    # Only use the logged-in user's sales records.
    sales_records = SalesData.query.filter_by(
        user_id=session["user_id"]
    ).order_by(SalesData.date.asc()).all()

    total_sales = sum(sale.quantity for sale in sales_records)
    total_revenue = sum(
        sale.quantity * sale.price for sale in sales_records
    )
    total_orders = len(sales_records)
    total_products = len({sale.product_name for sale in sales_records})
    profit_loss = calculate_profit_loss(sales_records)
    profit_graphs = build_profit_loss_charts(profit_loss)

    # Forecast the next day from the user's historical daily revenue.
    # This replaces the old fixed 15% multiplier.
    predicted_sales = 0.0
    monthly_growth = 0.0

    if sales_records:
        rows = [{
            "Date": pd.to_datetime(sale.date),
            "Revenue": float(sale.quantity) * float(sale.price)
        } for sale in sales_records]

        history = pd.DataFrame(rows)
        daily_sales = (
            history.groupby("Date", as_index=False)["Revenue"]
            .sum()
            .sort_values("Date")
        )

        if len(daily_sales) >= 2:
            first_date = daily_sales["Date"].min()
            daily_sales["DayNumber"] = (
                daily_sales["Date"] - first_date
            ).dt.days

            # Linear regression learns the direction of the historical trend.
            model = LinearRegression()
            model.fit(daily_sales[["DayNumber"]], daily_sales["Revenue"])

            next_day_number = int(daily_sales["DayNumber"].max()) + 1
            predicted_sales = max(
                0.0,
                float(model.predict(pd.DataFrame({
                    "DayNumber": [next_day_number]
                }))[0])
            )

            # Show the estimated change from the latest recorded day.
            latest_revenue = float(daily_sales.iloc[-1]["Revenue"])
            if latest_revenue > 0:
                monthly_growth = (
                    (predicted_sales - latest_revenue) / latest_revenue
                ) * 100
        else:
            # One date is not enough to learn a trend; use a neutral baseline.
            predicted_sales = float(daily_sales.iloc[-1]["Revenue"])

    trend_alert = None
    if sales_records:
        recent = pd.DataFrame([{"Date": pd.Timestamp(r.date), "Revenue": r.quantity * r.price} for r in sales_records])
        monthly_recent = recent.set_index("Date").resample("MS")["Revenue"].sum()
        if len(monthly_recent) >= 2:
            previous = float(monthly_recent.iloc[-2]); current = float(monthly_recent.iloc[-1])
            if previous > 0:
                pct = (current - previous) / previous * 100
                if pct <= -20:
                    trend_alert = f"Sales warning: latest month revenue is down {abs(pct):.1f}% versus the previous month."
                elif pct >= 20:
                    trend_alert = f"Sales alert: latest month revenue is up {pct:.1f}% versus the previous month."
    return render_template(
        "dashboard.html",
        username=session["username"],
        trend_alert=trend_alert,
        total_sales=total_sales,
        total_revenue=total_revenue,
        total_orders=total_orders,
        total_products=total_products,
        monthly_growth=monthly_growth,
        predicted_sales=predicted_sales,
        profit_loss=profit_loss,
        profit_graphs=profit_graphs
    )


# =========================================================
# ADD SALES DATA
# =========================================================

@app.route("/sales-data", methods=["GET", "POST"])
def sales_data():

    if not login_required():

        flash(
            "Please login first!"
        )

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        try:

            # -----------------------------
            # GET FORM VALUES
            # -----------------------------

            sale_date = pd.to_datetime(

                request.form.get("date")

            ).date()


            product_name = request.form.get(
                "product_name",
                ""
            ).strip()


            product_category = request.form.get(
                "product_category",
                ""
            ).strip()


            quantity = int(

                request.form.get(
                    "quantity"
                )

            )


            price = float(

                request.form.get(
                    "price"
                )

            )


            cost_price_raw = request.form.get("cost_price", "").strip()
            cost_price = float(cost_price_raw) if cost_price_raw else None

            customer_location = request.form.get(
                "customer_location",
                ""
            ).strip()


            # -----------------------------
            # VALIDATION
            # -----------------------------

            if not product_name:

                flash(
                    "Product name is required!"
                )

                return redirect(
                    url_for("sales_data")
                )


            if not product_category:

                flash(
                    "Product category is required!"
                )

                return redirect(
                    url_for("sales_data")
                )


            if not customer_location:

                flash(
                    "Customer location is required!"
                )

                return redirect(
                    url_for("sales_data")
                )


            if quantity <= 0:

                flash(
                    "Quantity must be greater than 0!"
                )

                return redirect(
                    url_for("sales_data")
                )


            if price < 0:
                flash("Selling price cannot be negative!")
                return redirect(url_for("sales_data"))
            if cost_price is not None and cost_price < 0:
                flash("Purchase cost cannot be negative!")
                return redirect(url_for("sales_data"))


            # =================================================
            # CREATE SALES RECORD
            # =================================================

            new_sale = SalesData(

                # VERY IMPORTANT
                # Attach sale to logged-in user

                user_id=session["user_id"],

                date=sale_date,

                product_name=product_name,

                product_category=product_category,

                quantity=quantity,

                price=price,
                cost_price=cost_price,

                customer_location=customer_location

            )


            db.session.add(
                new_sale
            )

            db.session.commit()


            flash(
                "Sales Data Added Successfully!"
            )


            # Go directly to analysis

            return redirect(
                url_for("analysis")
            )


        except Exception as error:

            db.session.rollback()

            print(
                "SALES DATA ERROR:",
                error
            )

            flash(
                f"Error: {error}"
            )

            return redirect(
                url_for("sales_data")
            )


    return render_template(
        "sales_data.html"
    )


# =========================================================
# CSV UPLOAD
# =========================================================

@app.route("/upload-csv", methods=["GET", "POST"])
def upload_csv():
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename:
            flash("Please select a CSV file.")
            return redirect(url_for("upload_csv"))
        if not allowed_file(file.filename):
            flash("Please upload a .csv file only.")
            return redirect(url_for("upload_csv"))

        raw = file.read()
        if not raw:
            flash("The selected CSV file is empty.")
            return redirect(url_for("upload_csv"))
        file_hash = hashlib.sha256(raw).hexdigest()
        user_id = session["user_id"]
        if UploadHistory.query.filter_by(user_id=user_id, file_hash=file_hash).first():
            flash("This exact CSV file has already been imported. No duplicate records were added.")
            return redirect(url_for("analysis"))

        try:
            data = pd.read_csv(io.BytesIO(raw))
            # Normalize column names, while keeping support for the example CSV formats.
            normalized = {str(c).strip().lower().replace(" ", "").replace("_", ""): c for c in data.columns}
            aliases = {
                "date": ["date", "saledate"],
                "product": ["product", "productname", "item"],
                "category": ["category", "productcategory"],
                "quantity": ["quantity", "qty", "unitssold"],
                "price": ["price", "unitprice", "priceperunit", "sellingprice", "sellingpriceperunit"],
                "cost_price": ["costprice", "purchaseprice", "unitcost", "purchasecost", "costperunit", "buyingprice"],
                "location": ["customerlocation", "location", "customerregion", "region"],
                "stock": ["stockonhand", "stock", "currentstock", "inventory"]
            }
            selected = {}
            for key, choices in aliases.items():
                for choice in choices:
                    if choice in normalized:
                        selected[key] = normalized[choice]
                        break
            required = ["date", "product", "category", "quantity", "price"]
            missing = [key for key in required if key not in selected]
            if missing:
                flash("Missing required CSV columns: " + ", ".join(missing) + ". Required: Date, Product, Category, Quantity, Price. CustomerLocation is optional.")
                return redirect(url_for("upload_csv"))

            cleaned = pd.DataFrame()
            cleaned["Date"] = pd.to_datetime(data[selected["date"]], errors="coerce")
            cleaned["Product"] = data[selected["product"]].astype("string").str.strip()
            cleaned["Category"] = data[selected["category"]].astype("string").str.strip()
            cleaned["Quantity"] = pd.to_numeric(data[selected["quantity"]], errors="coerce")
            cleaned["Price"] = pd.to_numeric(data[selected["price"]], errors="coerce")
            if "cost_price" in selected:
                raw_cost = data[selected["cost_price"]]
                numeric_cost = pd.to_numeric(raw_cost, errors="coerce")
                cleaned["CostPrice"] = numeric_cost
                cleaned["CostPriceInvalid"] = raw_cost.astype("string").fillna("").str.strip().ne("") & numeric_cost.isna()
            else:
                cleaned["CostPrice"] = None
                cleaned["CostPriceInvalid"] = False
            if "location" in selected:
                cleaned["Location"] = data[selected["location"]].astype("string").fillna("Unknown").str.strip()
            else:
                cleaned["Location"] = "CSV Upload"
            before = len(cleaned)
            cleaned = cleaned.dropna(subset=["Date", "Product", "Category", "Quantity", "Price"])
            cleaned = cleaned[(cleaned["Product"] != "") & (cleaned["Category"] != "") & (cleaned["Quantity"] > 0) & (cleaned["Quantity"] % 1 == 0) & (cleaned["Price"] >= 0) & (~cleaned["CostPriceInvalid"]) & (cleaned["CostPrice"].isna() | (cleaned["CostPrice"] >= 0))]
            cleaned["Quantity"] = cleaned["Quantity"].astype(int)
            cleaned["Date"] = cleaned["Date"].dt.date
            cleaned["Location"] = cleaned["Location"].replace("", "Unknown").fillna("Unknown")
            if cleaned.empty:
                flash("No valid sales rows were found. Check dates, quantities, prices and required columns.")
                return redirect(url_for("upload_csv"))

            existing = SalesData.query.filter_by(user_id=user_id).all()
            existing_keys = {(r.date, r.product_name.strip().casefold(), r.product_category.strip().casefold(), int(r.quantity), round(float(r.price), 4), round(float(r.cost_price), 4) if getattr(r, "cost_price", None) is not None else None, (r.customer_location or "").strip().casefold()) for r in existing}
            added = 0
            skipped_duplicates = 0
            for row in cleaned.to_dict("records"):
                key = (row["Date"], str(row["Product"]).casefold(), str(row["Category"]).casefold(), int(row["Quantity"]), round(float(row["Price"]), 4), round(float(row["CostPrice"]), 4) if pd.notna(row["CostPrice"]) else None, str(row["Location"]).casefold())
                if key in existing_keys:
                    skipped_duplicates += 1
                    continue
                db.session.add(SalesData(
                    user_id=user_id, date=row["Date"], product_name=str(row["Product"]),
                    product_category=str(row["Category"]), quantity=int(row["Quantity"]),
                    price=float(row["Price"]),
                    cost_price=float(row["CostPrice"]) if pd.notna(row["CostPrice"]) else None,
                    customer_location=str(row["Location"])
                ))
                existing_keys.add(key)
                added += 1

            # Optional stock snapshot: if a StockOnHand/Stock column exists, keep the latest
            # valid value per product for inventory planning. This is separate from sales rows.
            if "stock" in selected:
                stock_col = selected["stock"]
                stock_values = pd.to_numeric(data[stock_col], errors="coerce")
                for product_value, stock_value in zip(data[selected["product"]], stock_values):
                    product_value = str(product_value).strip()
                    if product_value and pd.notna(stock_value) and stock_value >= 0 and float(stock_value).is_integer():
                        inventory = InventoryStock.query.filter_by(user_id=user_id, product_name=product_value).first()
                        if inventory is None:
                            inventory = InventoryStock(user_id=user_id, product_name=product_value, stock_on_hand=int(stock_value))
                            db.session.add(inventory)
                        else:
                            inventory.stock_on_hand = int(stock_value)

            db.session.add(UploadHistory(user_id=user_id, file_hash=file_hash, filename=secure_filename(file.filename)[:255]))
            db.session.commit()
            dropped = before - len(cleaned)
            cost_note = " Purchase-cost column detected; profit/loss is calculated where costs are provided." if "cost_price" in selected else " No purchase-cost column found; profit/loss remains unavailable for these rows until costs are supplied."
            flash(f"CSV processed: {added} new records added, {skipped_duplicates} duplicate rows skipped, {dropped} invalid rows ignored.{cost_note}")
            return redirect(url_for("analysis"))
        except Exception as error:
            db.session.rollback()
            app.logger.exception("CSV upload failed")
            flash(f"Could not process CSV: {error}")
            return redirect(url_for("upload_csv"))

    return render_template("upload_csv.html")


@app.route("/analysis")
def analysis():

    if not login_required():

        flash(
            "Please login first!"
        )

        return redirect(
            url_for("login")
        )


    # =====================================================
    # GET ONLY CURRENT USER'S SALES
    # =====================================================

    all_records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    date_from = request.args.get("date_from", "").strip()
    date_to = request.args.get("date_to", "").strip()
    selected_product = request.args.get("product", "").strip()
    selected_category = request.args.get("category", "").strip()
    selected_location = request.args.get("location", "").strip()
    sales_records = all_records
    try:
        if date_from:
            min_date = pd.to_datetime(date_from, errors="raise").date()
            sales_records = [r for r in sales_records if r.date >= min_date]
        if date_to:
            max_date = pd.to_datetime(date_to, errors="raise").date()
            sales_records = [r for r in sales_records if r.date <= max_date]
    except Exception:
        flash("Invalid date filter was ignored.")
        date_from = date_to = ""
        sales_records = all_records
    if selected_product:
        sales_records = [r for r in sales_records if r.product_name == selected_product]
    if selected_category:
        sales_records = [r for r in sales_records if r.product_category == selected_category]
    if selected_location:
        sales_records = [r for r in sales_records if r.customer_location == selected_location]


    # =====================================================
    # NO DATA
    # =====================================================

    if not sales_records:

        return render_template(

            "analysis.html",

            sales_records=[],

            total_revenue=0,
            profit_loss=calculate_profit_loss([]),
            profit_graphs=build_profit_loss_charts(calculate_profit_loss([])),

            trend_graph="",

            quantity_graph="",

            monthly_graph="",

            category_graph="",

            product_graph="",
            products=sorted({r.product_name for r in all_records}),
            categories=sorted({r.product_category for r in all_records}),
            locations=sorted({r.customer_location for r in all_records}),
            date_from=date_from, date_to=date_to, selected_product=selected_product,
            selected_category=selected_category, selected_location=selected_location,
            filtered_count=0
        )


    # =====================================================
    # CREATE DATAFRAME
    # =====================================================

    data = []


    for sale in sales_records:

        revenue = (
            sale.quantity *
            sale.price
        )


        data.append({

            "ID": sale.id,

            "Date": sale.date,

            "Product": sale.product_name,

            "Category": sale.product_category,

            "Quantity": sale.quantity,

            "Price": sale.price,
            "CostPrice": getattr(sale, "cost_price", None),
            "Revenue": revenue,
            "Profit": (revenue - sale.quantity * sale.cost_price) if getattr(sale, "cost_price", None) is not None else None,
            "Location": sale.customer_location

        })


    df = pd.DataFrame(
        data
    )


    df["Date"] = pd.to_datetime(
        df["Date"]
    )


    df = df.sort_values(
        "Date"
    )


    # =====================================================
    # DAILY SALES
    # =====================================================

    daily_sales = (

        df.groupby("Date")

        .agg(

            Revenue=("Revenue", "sum"),

            Quantity=("Quantity", "sum")

        )

        .reset_index()

        .sort_values("Date")

    )


    # =====================================================
    # MONTHLY SALES
    # =====================================================

    monthly_sales = (

        df.set_index("Date")

        .resample("MS")

        .agg({

            "Revenue": "sum",

            "Quantity": "sum"

        })

        .reset_index()

    )


    # =====================================================
    # PRODUCT SALES
    # =====================================================

    product_sales = (

        df.groupby("Product")["Revenue"]

        .sum()

        .reset_index()

        .sort_values(
            "Revenue",
            ascending=False
        )

    )


    # =====================================================
    # CATEGORY SALES
    # =====================================================

    category_sales = (

        df.groupby("Category")["Revenue"]

        .sum()

        .reset_index()

    )


    # =====================================================
    # GRAPH 1
    # =====================================================

    trend_chart = px.line(

        daily_sales,

        x="Date",

        y="Revenue",

        markers=True,

        title="📈 Daily Sales Revenue"

    )


    trend_chart.update_layout(

        xaxis_title="Date",

        yaxis_title="Revenue",

        hovermode="x unified",

        template="plotly_white",

        height=500

    )


    trend_graph = pio.to_html(

        trend_chart,

        full_html=False,

        config={

            "responsive": True,

            "displayModeBar": True,

            "scrollZoom": True,

            "displaylogo": False

        }

    )


    # =====================================================
    # GRAPH 2
    # =====================================================

    quantity_chart = px.line(

        daily_sales,

        x="Date",

        y="Quantity",

        markers=True,

        title="📦 Daily Quantity Sold"

    )


    quantity_chart.update_layout(

        xaxis_title="Date",

        yaxis_title="Quantity",

        hovermode="x unified",

        template="plotly_white",

        height=500

    )


    quantity_graph = pio.to_html(

        quantity_chart,

        full_html=False,

        config={

            "responsive": True,

            "displayModeBar": True,

            "scrollZoom": True,

            "displaylogo": False

        }

    )


    # =====================================================
    # GRAPH 3
    # =====================================================

    monthly_chart = px.bar(

        monthly_sales,

        x="Date",

        y="Revenue",

        title="📊 Monthly Revenue"

    )


    monthly_chart.update_layout(

        xaxis_title="Month",

        yaxis_title="Revenue",

        template="plotly_white",

        height=500

    )


    monthly_graph = pio.to_html(

        monthly_chart,

        full_html=False,

        config={

            "responsive": True,

            "displayModeBar": True,

            "displaylogo": False

        }

    )


    # =====================================================
    # GRAPH 4
    # =====================================================

    category_chart = px.pie(

        category_sales,

        names="Category",

        values="Revenue",

        title="🥧 Revenue by Product Category"

    )


    category_chart.update_layout(

        template="plotly_white",

        height=500

    )


    category_graph = pio.to_html(

        category_chart,

        full_html=False,

        config={

            "responsive": True,

            "displayModeBar": True,

            "displaylogo": False

        }

    )


    # =====================================================
    # GRAPH 5
    # =====================================================

    top_products = product_sales.head(10)


    product_chart = px.bar(

        top_products,

        x="Product",

        y="Revenue",

        title="🏆 Top Selling Products"

    )


    product_chart.update_layout(

        xaxis_title="Product",

        yaxis_title="Revenue",

        template="plotly_white",

        height=500

    )


    product_graph = pio.to_html(

        product_chart,

        full_html=False,

        config={

            "responsive": True,

            "displayModeBar": True,

            "displaylogo": False

        }

    )


    # =====================================================
    # TOTAL REVENUE
    # =====================================================

    total_revenue = df["Revenue"].sum()


    # =====================================================
    # SEND EVERYTHING TO HTML
    # =====================================================

    return render_template(

        "analysis.html",

        sales_records=sales_records,

        total_revenue=total_revenue,
        profit_loss=calculate_profit_loss(sales_records),
        profit_graphs=build_profit_loss_charts(calculate_profit_loss(sales_records)),

        daily_sales=daily_sales.to_dict(
            "records"
        ),

        monthly_sales=monthly_sales.to_dict(
            "records"
        ),

        product_sales=product_sales.to_dict(
            "records"
        ),

        category_sales=category_sales.to_dict(
            "records"
        ),

        trend_graph=trend_graph,

        quantity_graph=quantity_graph,

        monthly_graph=monthly_graph,

        category_graph=category_graph,

        product_graph=product_graph,
        products=sorted({r.product_name for r in all_records}),
        categories=sorted({r.product_category for r in all_records}),
        locations=sorted({r.customer_location for r in all_records}),
        date_from=date_from, date_to=date_to, selected_product=selected_product,
        selected_category=selected_category, selected_location=selected_location,
        filtered_count=len(sales_records)
    )


# =========================================================
# DELETE SALES RECORD
# =========================================================

@app.route(
    "/delete-sale/<int:sale_id>",
    methods=["POST"]
)
def delete_sale(sale_id):

    if not login_required():

        flash(
            "Please login first!"
        )

        return redirect(
            url_for("login")
        )


    # =====================================================
    # VERY IMPORTANT
    # ONLY DELETE CURRENT USER'S RECORD
    # =====================================================

    sale = SalesData.query.filter_by(

        id=sale_id,

        user_id=session["user_id"]

    ).first()


    if sale is None:

        flash(
            "Sales record not found!"
        )

        return redirect(
            url_for("analysis")
        )


    db.session.delete(
        sale
    )

    db.session.commit()


    flash(
        "Sales record deleted successfully!"
    )


    return redirect(
        url_for("analysis")
    )


# =========================================================
# FORECAST
# =========================================================

@app.route("/profit-loss")
def profit_loss_page():
    """Dedicated product-wise and weekly/monthly/yearly profit/loss page."""
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))
    records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    summary = calculate_profit_loss(records)
    graphs = build_profit_loss_charts(summary)
    return render_template("profit_loss.html", username=session.get("username", "User"), profit_loss=summary, profit_graphs=graphs)


def _forecast_impl():
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))

    records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    if not records:
        flash("Upload a CSV or add sales records before forecasting.")
        return redirect(url_for("dashboard"))

    horizon = request.args.get("months", "3")
    if horizon not in {"1", "3", "6"}:
        horizon = "3"
    horizon_months = int(horizon)
    raw = pd.DataFrame([{"Date": pd.Timestamp(r.date), "Revenue": float(r.quantity) * float(r.price), "Quantity": int(r.quantity)} for r in records])
    raw = raw.dropna(subset=["Date", "Revenue"]).sort_values("Date")
    if raw.empty:
        flash("No valid dated sales records are available to forecast. Please correct your sales data.")
        return redirect(url_for("dashboard"))
    daily = raw.groupby("Date", as_index=False).agg(Revenue=("Revenue", "sum"), Quantity=("Quantity", "sum")).sort_values("Date")
    monthly = raw.set_index("Date").resample("MS").agg(Revenue=("Revenue", "sum"), Quantity=("Quantity", "sum")).reset_index()
    # Empty calendar months between first and last observation are meaningful zero-sales months.
    if not monthly.empty:
        full_months = pd.date_range(monthly["Date"].min(), monthly["Date"].max(), freq="MS")
        monthly = monthly.set_index("Date").reindex(full_months, fill_value=0).rename_axis("Date").reset_index()

    monthly["MonthIndex"] = range(len(monthly))
    y = monthly["Revenue"].astype(float).to_numpy()
    model_name = "Linear Regression"
    model = LinearRegression()
    evaluation_rows = []
    metrics = {"mae": None, "rmse": None, "mape": None, "test_points": 0}
    # Chronological holdout evaluation: train on earlier months, test on the latest months.
    if len(monthly) >= 5:
        test_size = max(1, min(3, int(round(len(monthly) * 0.2))))
        split = len(monthly) - test_size
        train_x = monthly[["MonthIndex"]].iloc[:split]
        test_x = monthly[["MonthIndex"]].iloc[split:]
        train_y = y[:split]
        test_y = y[split:]
        lr_eval = LinearRegression().fit(train_x, train_y).predict(test_x)
        baseline_eval = [float(train_y[-min(3, len(train_y)):].mean())] * len(test_y)
        candidates = [("Linear Regression", lr_eval), ("Moving Average Baseline", baseline_eval)]
        for name, preds in candidates:
            # Keep predictions as a NumPy array: the moving-average candidate is
            # initially a Python list, which cannot be indexed by a NumPy mask.
            preds_array = pd.Series(preds, dtype="float64").to_numpy()
            mae = float(mean_absolute_error(test_y, preds_array))
            rmse = float(mean_squared_error(test_y, preds_array) ** 0.5)
            nonzero = test_y != 0
            mape = float((abs((test_y[nonzero] - preds_array[nonzero]) / test_y[nonzero]).mean() * 100)) if nonzero.any() else None
            evaluation_rows.append({"model": name, "mae": mae, "rmse": rmse, "mape": mape})
        # Choose the model with lower holdout MAE; all predictions remain estimates.
        best = min(evaluation_rows, key=lambda row: row["mae"])
        model_name = best["model"]
        metrics = {"mae": best["mae"], "rmse": best["rmse"], "mape": best["mape"], "test_points": test_size}

    future_dates = pd.date_range(monthly["Date"].max() + pd.offsets.MonthBegin(1), periods=horizon_months, freq="MS")
    if model_name == "Moving Average Baseline":
        future_values = [max(0.0, float(y[-min(3, len(y)):].mean()))] * horizon_months
    else:
        model.fit(monthly[["MonthIndex"]], y)
        future_indices = list(range(len(monthly), len(monthly) + horizon_months))
        future_values = [max(0.0, float(v)) for v in model.predict(pd.DataFrame({"MonthIndex": future_indices}))]
    future = pd.DataFrame({"Date": future_dates, "PredictedSales": future_values})

    # Actual vs predicted chart uses chronological holdout predictions where possible.
    chart = px.line(monthly, x="Date", y="Revenue", markers=True, title="Historical Monthly Revenue and Forecast")
    chart.add_scatter(x=future["Date"], y=future["PredictedSales"], mode="lines+markers", name=f"Forecast ({model_name})")
    if len(monthly) >= 5:
        test_size = metrics["test_points"]
        split = len(monthly) - test_size
        if model_name == "Moving Average Baseline":
            hist_preds = [float(y[:split][-min(3, split):].mean())] * test_size
        else:
            eval_model = LinearRegression().fit(monthly[["MonthIndex"]].iloc[:split], y[:split])
            hist_preds = eval_model.predict(monthly[["MonthIndex"]].iloc[split:])
        chart.add_scatter(x=monthly["Date"].iloc[split:], y=hist_preds, mode="markers", name="Holdout predictions")
    chart.update_layout(xaxis_title="Month", yaxis_title="Revenue (₹)", hovermode="x unified", template="plotly_white", height=520)
    forecast_graph = pio.to_html(chart, full_html=False, config={"responsive": True, "displayModeBar": True, "displaylogo": False})

    # Product-level demand insight and optional stock recommendations (CSV StockOnHand/Stock column).
    # Estimate monthly units per product from the underlying sales records.
    product_rows = pd.DataFrame([{"Product": r.product_name, "Quantity": r.quantity, "Date": pd.Timestamp(r.date)} for r in records])
    product_months = product_rows.groupby(["Product", product_rows["Date"].dt.to_period("M")])["Quantity"].sum().reset_index(name="Units")
    inventory_tips = []
    stock_rows = {item.product_name: item.stock_on_hand for item in InventoryStock.query.filter_by(user_id=session["user_id"]).all()}
    for product, group in product_months.groupby("Product"):
        avg_monthly = float(group["Units"].mean())
        planned_units = max(0, int(round(avg_monthly * horizon_months)))
        stock_on_hand = stock_rows.get(product)
        if stock_on_hand is None:
            recommendation = f"Plan around {planned_units} units for the next {horizon_months} month(s); upload a StockOnHand column to estimate reorder needs."
            reorder = None
        else:
            reorder = max(0, planned_units - int(stock_on_hand))
            recommendation = f"Estimated reorder quantity: {reorder} unit(s), using current stock of {stock_on_hand}. Adjust for supplier lead time and safety stock."
        inventory_tips.append({"product": product, "avg_monthly_units": round(avg_monthly, 1), "planned_units": planned_units, "stock_on_hand": stock_on_hand, "reorder_quantity": reorder, "recommendation": recommendation})
    inventory_tips = sorted(inventory_tips, key=lambda r: r["avg_monthly_units"], reverse=True)[:10]

    latest_month = float(y[-1]) if len(y) else 0.0
    next_pred = float(future_values[0]) if future_values else 0.0
    trend_percent = ((next_pred - latest_month) / latest_month * 100) if latest_month > 0 else None
    return render_template(
        "forecast.html", prediction=next_pred, next_date=future_dates[0].strftime("%B %Y"),
        forecast_graph=forecast_graph, total_records=len(records), total_forecast=float(sum(future_values)),
        average_forecast=float(sum(future_values) / len(future_values)) if future_values else 0,
        forecast_days=horizon_months, horizon_months=horizon_months, model_name=model_name,
        metrics=metrics, evaluation_rows=evaluation_rows, inventory_tips=inventory_tips,
        trend_percent=trend_percent, historical_months=len(monthly)
    )


@app.route("/forecast")
def forecast():
    """Run the forecast and turn unexpected failures into a visible, logged message."""
    try:
        return _forecast_impl()
    except Exception as exc:
        app.logger.exception("Forecast page failed")
        # Show a useful diagnostic rather than Flask's generic Internal Server Error.
        flash(f"Forecast could not be generated ({type(exc).__name__}). Check the VS Code terminal for the detailed error, then verify your CSV dates, quantities, and prices.", "error")
        return redirect(url_for("dashboard"))


@app.route("/reports/sales.csv")
def download_sales_csv():
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))
    records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Product", "Category", "Quantity", "SellingPrice", "PurchaseCost", "Revenue", "ProfitLoss", "CustomerLocation"])
    for r in records:
        revenue = round(r.quantity * r.price, 2)
        cost = round(r.quantity * r.cost_price, 2) if getattr(r, "cost_price", None) is not None else None
        profit = round(revenue - cost, 2) if cost is not None else None
        writer.writerow([r.date.isoformat(), r.product_name, r.product_category, r.quantity, r.price, r.cost_price, revenue, profit, r.customer_location])
    from flask import Response
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=sales_report.csv"})


@app.route("/reports/forecast.csv")
def download_forecast_csv():
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))
    records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    if not records:
        flash("No sales data available to forecast.")
        return redirect(url_for("forecast"))
    months = request.args.get("months", "3")
    months = int(months) if months in {"1", "3", "6"} else 3
    frame = pd.DataFrame([{"Date": pd.Timestamp(r.date), "Revenue": r.quantity * r.price} for r in records])
    monthly = frame.set_index("Date").resample("MS")["Revenue"].sum().reset_index()
    monthly["MonthIndex"] = range(len(monthly))
    if len(monthly) < 2:
        flash("Add sales from at least two different months for monthly forecasting.")
        return redirect(url_for("forecast"))
    model_name = "Linear Regression"
    if len(monthly) >= 5:
        test_size = max(1, min(3, int(round(len(monthly) * 0.2))))
        split = len(monthly) - test_size
        test_y = monthly["Revenue"].to_numpy()[split:]
        lr_eval = LinearRegression().fit(monthly[["MonthIndex"]].iloc[:split], monthly["Revenue"].iloc[:split]).predict(monthly[["MonthIndex"]].iloc[split:])
        ma_eval = [float(monthly["Revenue"].iloc[:split].tail(3).mean())] * test_size
        if mean_absolute_error(test_y, ma_eval) < mean_absolute_error(test_y, lr_eval):
            model_name = "Moving Average Baseline"
    future_dates = pd.date_range(monthly["Date"].max() + pd.offsets.MonthBegin(1), periods=months, freq="MS")
    if model_name == "Moving Average Baseline":
        preds = [float(monthly["Revenue"].tail(3).mean())] * months
    else:
        model = LinearRegression().fit(monthly[["MonthIndex"]], monthly["Revenue"])
        preds = model.predict(pd.DataFrame({"MonthIndex": range(len(monthly), len(monthly) + months)}))
    output = io.StringIO(); writer = csv.writer(output)
    writer.writerow(["Month", "PredictedRevenue"])
    for d, value in zip(future_dates, preds): writer.writerow([d.strftime("%Y-%m"), round(max(0.0, float(value)), 2)])
    from flask import Response
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=sales_forecast.csv"})


@app.route("/reports/pdf")
def download_pdf_report():
    if not login_required():
        flash("Please login first!")
        return redirect(url_for("login"))
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter, landscape
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet
    except ImportError:
        flash("PDF reports need reportlab. Install it with: python -m pip install reportlab")
        return redirect(url_for("analysis"))
    records = SalesData.query.filter_by(user_id=session["user_id"]).order_by(SalesData.date.asc()).all()
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(letter), rightMargin=24, leftMargin=24, topMargin=24, bottomMargin=24)
    styles = getSampleStyleSheet()
    story = [Paragraph("Sales Forecasting System — Sales Report", styles["Title"]), Spacer(1, 10)]
    revenue = sum(r.quantity * r.price for r in records)
    pl = calculate_profit_loss(records)
    story.append(Paragraph(f"User: {session.get('username', 'User')} | Records: {len(records)} | Revenue: Rs. {revenue:,.2f} | Known purchase cost: Rs. {pl['total_cost']:,.2f} | Net profit/loss on records with known cost: Rs. {pl['net_profit']:,.2f} | Records missing cost: {pl['unknown_cost_records']}", styles["Normal"]))
    story.append(Spacer(1, 12))
    rows = [["Date", "Product", "Category", "Qty", "Sell/unit", "Cost/unit", "Revenue", "Profit/Loss", "Location"]]
    for r in records[:5000]:
        rev = r.quantity * r.price
        cost = r.quantity * r.cost_price if getattr(r, "cost_price", None) is not None else None
        prof = rev - cost if cost is not None else None
        rows.append([r.date.strftime("%Y-%m-%d"), r.product_name[:22], r.product_category[:16], str(r.quantity), f"{r.price:,.2f}", f"{r.cost_price:,.2f}" if r.cost_price is not None else "Unknown", f"{rev:,.2f}", f"{prof:,.2f}" if prof is not None else "Unknown", (r.customer_location or "")[:18]])
    table = Table(rows, repeatRows=1, colWidths=[58, 82, 68, 30, 52, 52, 62, 65, 75])
    table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#23395d")), ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("GRID", (0,0), (-1,-1), 0.35, colors.lightgrey), ("FONTSIZE", (0,0), (-1,-1), 8), ("VALIGN", (0,0), (-1,-1), "TOP"), ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f3f6fa")])]))
    story.append(table)
    if len(records) > 5000: story.append(Paragraph("Note: Report is limited to the first 5,000 records.", styles["Italic"]))
    doc.build(story)
    from flask import Response
    return Response(buffer.getvalue(), mimetype="application/pdf", headers={"Content-Disposition": "attachment; filename=sales_report.pdf"})


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    flash(
        "You have been logged out!"
    )

    return redirect(
        url_for("home")
    )


# =========================================================
# CREATE DATABASE
# =========================================================

with app.app_context():
    db.create_all()
    # Add the new nullable column to existing SQLite databases without deleting data.
    try:
        columns = {column["name"] for column in inspect(db.engine).get_columns("sales_data")}
        if "cost_price" not in columns:
            with db.engine.begin() as connection:
                connection.exec_driver_sql("ALTER TABLE sales_data ADD COLUMN cost_price FLOAT")
    except Exception:
        app.logger.exception("Could not verify/migrate sales_data.cost_price column")


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )