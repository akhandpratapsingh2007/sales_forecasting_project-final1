SALES FORECASTING SYSTEM — ENHANCED EDITION
===========================================

FEATURES INCLUDED
1. CSV upload with required-column validation and common column-name aliases.
2. Data cleaning for dates, quantities, prices, blank values and invalid rows.
3. Duplicate protection: exact same CSV hash is not imported twice, and matching existing sales rows are skipped.
4. Optional CustomerLocation/Location column is retained.
5. Optional StockOnHand/Stock column stores current stock per product for inventory planning.
6. User-specific sales data: records and reports are filtered to the logged-in user.
7. Dashboard revenue, order count, product count, next-day trend estimate and sales trend alerts.
8. Analysis filters: date range, product, category and location.
9. Interactive Plotly charts for daily revenue, quantity, monthly revenue, category revenue and top products.
10. Monthly forecasts for 1, 3 or 6 months.
11. Forecast model comparison between Linear Regression and a moving-average baseline.
12. Chronological holdout evaluation with MAE, RMSE and MAPE (MAPE is unavailable when test actuals are all zero).
13. Historical/forecast chart and holdout prediction markers.
14. Product demand planning and optional stock-aware reorder estimates.
15. Downloadable sales CSV, forecast CSV and PDF report.
16. Dark/light appearance toggle on dashboard, analysis and forecast pages.

REQUIREMENTS / RUN
1. Extract this ZIP.
2. Open the extracted project folder in VS Code.
3. Create/activate a virtual environment if desired.
4. Install packages:
   python -m pip install -r requirements.txt
5. Run:
   python 1_app.py
6. Open the local URL shown in the terminal (usually http://127.0.0.1:5000).
7. Register/login, upload a CSV, then check Dashboard, Analysis and Forecast.

CSV REQUIRED COLUMNS
Date, Product, Category, Quantity, Price (or SellingPrice)

OPTIONAL COLUMNS
PurchaseCost (or CostPrice, PurchasePrice, UnitCost, CostPerUnit, BuyingPrice) — unit purchase cost for profit/loss calculations.
CustomerLocation (or Location) — for location analysis.
StockOnHand (or Stock) — current product stock used for reorder estimates.

Forecast notes:
- The model forecasts monthly revenue using historical monthly revenue.
- Model evaluation uses a chronological holdout; it does not shuffle time-series rows.
- At least five months of data are recommended for a useful model comparison; more history is better.
- A moving-average baseline may be selected if it has lower holdout MAE than Linear Regression.
- MAPE can be misleading or unavailable when actual sales are zero/near zero; interpret metrics in context.
- Inventory reorder quantities are planning estimates based on average observed monthly unit sales and supplied stock. They do not account automatically for lead times, safety stock, promotions or future demand changes.
- Forecasts are estimates, not guarantees. They do not inherently know holidays, marketing activity or market changes.

SECURITY / DEPLOYMENT NOTES
- The project uses a development fallback secret key. Set the FLASK_SECRET_KEY environment variable to a long random value before deployment.
- Do not use Flask debug mode or the built-in development server for public production hosting.
- Keep the SQLite database private and back it up before replacing project files.


PROFIT & LOSS FEATURES
----------------------
- Selling price per unit is stored in the Price/SellingPrice column.
- Purchase cost per unit can be supplied as PurchaseCost, CostPrice, PurchasePrice, UnitCost, CostPerUnit, or BuyingPrice.
- Profit/Loss per record = (Selling Price - Purchase Cost) x Quantity.
- Dashboard and Analysis show product-wise, weekly, monthly, and yearly profit/loss summaries.
- CSV and PDF reports include purchase cost and profit/loss.
- Purchase cost is optional for backward compatibility. Rows without it are clearly marked as unknown/incomplete and are excluded from net profit/loss totals.
- Existing SQLite databases are migrated on app startup by adding a nullable cost_price column; existing sales data is preserved.
- Negative quantity or selling price rows are rejected as invalid sales. Do not enter negative sales to represent returns; model returns/refunds as a separate transaction type if that feature is needed.

Recommended CSV header:
Date,Product,Category,Quantity,SellingPrice,PurchaseCost,CustomerLocation,StockOnHand

Example:
2026-01-03,Laptop,Electronics,7,50000,42000,Delhi,12

IMPORTANT:
Revenue is not profit. Accurate profit/loss requires the real purchase cost for each product/transaction. If purchase cost is absent, the system will not invent it.


LATEST FIX (2026-10-17): Added a dedicated Profit & Loss page at /profit-loss with a visible navigation link, product-wise report, and weekly/monthly/yearly tables and charts. Dashboard and forecast navigation now expose View Forecast and Profit & Loss links. Removed stray Markdown code-fence markers from dashboard HTML that could disrupt page rendering. Forecast now handles invalid dated records with a clear message instead of attempting to chart an empty dataset.


LATEST DIAGNOSTIC FIX (2026-10-17)
---------------------------------
- Fixed forecast model evaluation when the moving-average baseline is evaluated. Its predictions were a Python list, but the MAPE calculation indexed them with a NumPy boolean mask, which can raise a TypeError and break the Forecast page. Predictions are now normalized to a numeric array before metrics are calculated.
- Made the dashboard navigation responsive and styled the forecast/profit-loss actions so they are easy to see.
- Unexpected forecast exceptions are logged to the VS Code terminal and a helpful message is shown on the dashboard instead of a generic error page.
