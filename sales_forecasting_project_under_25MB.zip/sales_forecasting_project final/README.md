Sales Forecasting System — organized project

Folder structure:
- app.py: Flask backend, database models, routes, CSV processing, forecasting and Profit & Loss logic.
- templates/: the ORIGINAL HTML template code from your supplied project.
- static/style.css: the original stylesheet.
- requirements.txt: Python dependencies.
- sample_sales_data.csv: sample CSV data.
- instance/database.db: project database supplied in the original ZIP.
- uploads/: uploaded CSV files are stored here while the app runs.

Run on Windows (from this folder):
  py -m venv myvenv
  .\myvenv\Scripts\activate
  python -m pip install -r requirements.txt
  python app.py

Then open the local URL printed in the terminal (usually http://127.0.0.1:5000).

Note: This package preserves the HTML and CSS code from the original ZIP. Do not move the
HTML files out of templates/ or the stylesheet out of static/ because Flask expects them there.
Keep a backup of instance/database.db before changing the database.
